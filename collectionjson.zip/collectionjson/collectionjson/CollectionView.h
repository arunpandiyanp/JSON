//
//  CollectionView.h
//  collectionjson
//
//  Created by Dinesh Jaganathan on 03/11/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectionView : UICollectionViewCell
{
   
}
@property(nonatomic,retain)IBOutlet UIImageView *img;
@property(nonatomic,retain)IBOutlet UILabel *lab;

@end
