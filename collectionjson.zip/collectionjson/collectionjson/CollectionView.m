//
//  CollectionView.m
//  collectionjson
//
//  Created by Dinesh Jaganathan on 03/11/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import "CollectionView.h"

@implementation CollectionView

@end
