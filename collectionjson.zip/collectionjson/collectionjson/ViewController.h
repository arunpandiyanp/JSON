//
//  ViewController.h
//  collectionjson
//
//  Created by Dinesh Jaganathan on 03/11/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
     IBOutlet UICollectionView *collect;
  
}

@end

